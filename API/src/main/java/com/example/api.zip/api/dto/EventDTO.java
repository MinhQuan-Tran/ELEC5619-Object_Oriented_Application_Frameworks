package com.example.api.dto;

public class EventDTO {
}
